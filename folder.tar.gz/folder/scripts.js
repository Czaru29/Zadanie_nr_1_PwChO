function renderTime(){
    
    var mydate = new Date(); 
    //Lublin
    var dayLublin = mydate.getDay();
    var monthLublin = mydate.getMonth();
    var dayLublin = mydate.getDate();
    //NY
    var dayNY = mydate.getDay();
    var monthNY = mydate.getMonth();
    var dayNY = mydate.getDate();
    //Sydney
    var daySydney = mydate.getDay();
    var monthSydney = mydate.getMonth();
    var daySydney = mydate.getDate();
    
    var montharray = new Array("Styczen","Luty","Marzec","Kwiecien","Maj","Czerwiec","Lipiec","Sierpien","Wrzesien","Pazdziernik","Listopad","Grudzien");

    var currentTime = new Date();
    //Lublin
    var hLublin = currentTime.getHours();
    var mLublin = currentTime.getMinutes();
    //NY
    var hNY = currentTime.getHours();
    var mNY = currentTime.getMinutes();
    //Sydney
    var hSydney = currentTime.getHours();
    var mSydney = currentTime.getMinutes();
        //NY timezone
        hNY -= 6;
        if(hNY < 0){
            hNY = 24 + hNY;
            dayNY -= 1;
        }
        //Sydney timezone
        hSydney += 10;

        if(hSydney >= 24){
            hSydney -= 24;
            daySydney += 1;
        }
    
        if(hLublin == 24){
            hLublin = 0;
        } else if(hLublin  > 12){
            hLublin  = hLublin  - 0;
        }
        if(hLublin  < 10){
            hLublin  = "0" + hLublin ;
        }
        if(mLublin < 10){
            mLublin = "0" + mLublin;
        }
        
        if(hNY == 24){
            hNY = 0;
        } else if(hNY > 12){
            hNY = hNY  - 0;
        }
        if(hNY < 10){
            hNY  = "0" + hNY ;
        }
        if(mNY < 10){
            mNY = "0" + mNY;
        }
        
        if(hSydney == 24){
            hSydney = 0;
        } else if(hSydney > 12){
            hSydney = hSydney  - 0;
        }
        if(hSydney< 10){
            hSydney  = "0" + hSydney ;
        }
        if(mSydney < 10){
            mSydney = "0" + mSydney;
        }

        
    var myClock = document.getElementById("clockDisplay1");
    myClock.textContent = "Lublin: " +dayLublin+ " " +montharray[monthLublin]+ " | " + hLublin+ " : " +mLublin;
    myClock.innerText = "Lublin: " +dayLublin+ " " +montharray[monthLublin]+ " | " + hLublin+ " : " +mLublin;
    
    var myClock = document.getElementById("clockDisplay2");
    myClock.textContent = "Nowy York: " +dayNY+ " " +montharray[monthNY]+ " | " + hNY+ " : " +mNY;
    myClock.innerText = "Nowy York: " +dayNY+ " " +montharray[monthNY]+ " | " + hNY+ " : " +mNY;
    
    var myClock = document.getElementById("clockDisplay3");
    myClock.textContent = "Sydney: " +daySydney+ " " +montharray[monthSydney]+ " | " + hSydney+ " : " +mSydney;
    myClock.innerText = "Sydney: " +daySydney+ " " +montharray[monthSydney]+ " | " + hSydney+ " : " +mSydney;
    
    setTimeout("renderTime()", 1000);

}
renderTime();


